﻿using Microsoft.AspNetCore.Mvc;
using WebFlyClient.Services;

namespace WebFlyClient.Controllers
{
    public class AveragePriceController : Controller
    {
        private readonly ILogger<AveragePriceController> _logger;
        private readonly IVsFlyServices _vsFlyServices;

        public AveragePriceController(ILogger<AveragePriceController> logger, IVsFlyServices vsFlyServices)
        {
            _logger = logger;
            _vsFlyServices = vsFlyServices;
        }

        /// <summary>
        /// Get the average sale price of a destination before displaying it
        /// </summary>
        /// <param name="destination"></param>
        /// <returns></returns>
        public async Task<IActionResult> Index(string destination)
        {
            var averagePrice = await _vsFlyServices.GetAveragePrice(destination);
            return View(averagePrice);
        }
    }

    
}
