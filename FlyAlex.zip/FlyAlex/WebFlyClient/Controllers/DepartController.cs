﻿using Microsoft.AspNetCore.Mvc;
using WebFlyClient.Models;
using WebFlyClient.Services;

namespace WebFlyClient.Controllers
{
    public class DepartController : Controller
    {
        private readonly ILogger<DepartController> _logger;
        private readonly IVsFlyServices _vsFlyServices;

        public DepartController(ILogger<DepartController> logger, IVsFlyServices vsFlyServices)
        {
            _logger = logger;
            _vsFlyServices = vsFlyServices;
        }

        /// <summary>
        /// Display index page
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> Index()
        {
            return View();
        }

        /// <summary>
        /// Redirect to the index page of the DestinationAverageSalePrice controller 
        /// </summary>
        /// <param name="destination">Desination object</param>
        /// <returns></returns>
        public IActionResult AveragePrice(Depart depart)
        {
            return RedirectToAction("Index", "AveragePrice", new { depart = depart.DepartName });
        }

        /// <summary>
        /// Redirect to the index page of the BookedTicket controller
        /// </summary>
        /// <param name="destination">Desination object</param>
        /// <returns></returns>
        public IActionResult BookedTickets(Depart depart)
        {
            return RedirectToAction("Index", "BookedTickets", new { depart = depart.DepartName });
        }

    }
}
