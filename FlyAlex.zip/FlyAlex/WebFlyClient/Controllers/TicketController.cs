﻿using Microsoft.AspNetCore.Mvc;
using WebFlyClient.Services;

namespace WebFlyClient.Controllers
{
    public class TicketController : Controller
    {
        private readonly ILogger<BookedTicketsController> _logger;
        private readonly IVsFlyServices _vsFlyServices;

        public BookedTicketsController(ILogger<BookedTicketsController> logger, IVsFlyServices vsFlyServices)
        {
            _logger = logger;
            _vsFlyServices = vsFlyServices;
        }

        /// <summary>
        /// Get the tickets from the destination before displaying them
        /// </summary>
        /// <param name="destination">Destination name</param>
        /// <returns></returns>
        public async Task<IActionResult> Index(string destination)
        {
            var tickets = await _vsFlyServices.GetBookedTickets(destination);
            return View(tickets);
        }
    }
}
