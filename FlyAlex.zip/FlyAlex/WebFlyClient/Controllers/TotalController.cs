﻿using Microsoft.AspNetCore.Mvc;
using WebFlyClient.Services;

namespace WebFlyClient.Controllers
{
    public class TotalController : Controller
    {
        private readonly ILogger<TotalController> _logger;
        private readonly IVsFlyServices _vsFlyServices;

        public TotalController(ILogger<TotalController> logger, IVsFlyServices vsFlyServices)
        {
            _logger = logger;
            _vsFlyServices = vsFlyServices;
        }

        /// <summary>
        /// Get the total sale price of a flight before displaying it
        /// </summary>
        /// <param name="id">Flight identifier</param>
        /// <returns></returns>
        public async Task<IActionResult> Index(int id)
        {
            var totalPrice = await _vsFlyServices.GetTotalSalePrice(id);
            return View(totalPrice);
        }
    }
}
