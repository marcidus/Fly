﻿using Microsoft.AspNetCore.Mvc;
using WebFlyClient.Models;
using WebFlyClient.Services;

namespace WebFlyClient.Controllers
{
    public class DestinationController : Controller
    {
        private readonly ILogger<DestinationController> _logger;
        private readonly IVsFlyServices _vsFlyServices;

        public DestinationController(ILogger<DestinationController> logger, IVsFlyServices vsFlyServices)
        {
            _logger = logger;
            _vsFlyServices = vsFlyServices;
        }
        /// <summary>
        /// Display index page
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> Index()
        {
            return View();
        }

        /// <summary>
        /// Redirect to the index page of the DestinationAverageSalePrice controller 
        /// </summary>
        /// <param name="destination">Desination object</param>
        /// <returns></returns>
        public IActionResult AveragePrice(Destination destination)
        {
            return RedirectToAction("Index", "AveragePrice", new { destination = destination.DestinationName });
        }

        /// <summary>
        /// Redirect to the index page of the BookedTicket controller
        /// </summary>
        /// <param name="destination">Desination object</param>
        /// <returns></returns>
        public IActionResult BookedTickets(Destination destination)
        {
            return RedirectToAction("Index", "Ticket", new { destination = destination.DestinationName });
        }
    }
}
