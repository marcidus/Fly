﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebFlyClient.Models;
using WebFlyClient.Services;

namespace WebFlyClient.Controllers
{
    public class AvailableFlightController : Controller
    {

        private readonly ILogger<AvailableFlightController> _logger;
        private readonly IVsFlyServices _vsFlyServices;

        public AvailableFlightController(ILogger<AvailableFlightController> logger, IVsFlyServices vsFlyServices)
        {
            _logger = logger;
            _vsFlyServices = vsFlyServices;
        }

        public async Task<IActionResult> Index()
        {
            var flights = await _vsFlyServices.GetFlights();
            return View(flights);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        /// <summary>
        /// Redirect to the index page of the SalePrice controller
        /// </summary>
        /// <param name="id">Identifier of the flight</param>
        /// <returns></returns>
        public IActionResult SalePrice(int id)
        {
            return RedirectToAction("Index", "SalePrice", new { id = id });
        }

        /// <summary>
        /// Redirect to the index page of the BookTicket controller
        /// </summary>
        /// <param name="id">Identifier of the flight</param>
        public IActionResult BookTicket(int id)
        {
            //Put the flightId in the session to retrive it in the other controller
            HttpContext.Session.SetInt32("flightId", id);
            return RedirectToAction("Index", "BookTicket");
        }

        /// <summary>
        /// Redirect to the index page of the TotalSalePrice controller
        /// </summary>
        /// <param name="id">Identifier of the flight</param>
        /// <returns></returns>
        public IActionResult TotalSalePrice(int id)
        {
            return RedirectToAction("Index", "TotalSalePrice", new { id = id });
        }

        /// <summary>
        /// Error default page
        /// </summary>
        /// <returns></returns>
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
