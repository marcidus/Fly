﻿using Microsoft.AspNetCore.Mvc;
using WebFlyClient.Services;

namespace WebFlyClient.Controllers
{
    public class SaleController : Controller
    {
        private readonly ILogger<SaleController> _logger;
        private readonly IVsFlyServices _vsFlyServices;

        public SaleController(ILogger<SaleController> logger, IVsFlyServices vsFlyServices)
        {
            _logger = logger;
            _vsFlyServices = vsFlyServices;
        }

        /// <summary>
        /// Get the sale price of a flight before displaying it
        /// </summary>
        /// <param name="id">Flight identifier</param>
        /// <returns></returns>
        public async Task<IActionResult> Index(int id)
        {
            var price = await _vsFlyServices.GetPrice(id);
            return View(price);
        }
    }
}
