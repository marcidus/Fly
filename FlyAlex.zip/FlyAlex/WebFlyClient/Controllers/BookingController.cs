﻿using Microsoft.AspNetCore.Mvc;
using WebFlyClient.Models;
using WebFlyClient.Services;

namespace WebFlyClient.Controllers
{
    public class BookingController : Controller
    {

        private readonly ILogger<BookingController> _logger;
        private readonly IVsFlyServices _vsFlyServices;

        public BookingController(ILogger<BookingController> logger, IVsFlyServices vsFlyServices)
        {
            _logger = logger;
            _vsFlyServices = vsFlyServices;
        }

        /// <summary>
        /// Display the index page with the flightId
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            return View( new TicketBooking { FlightID = (int)HttpContext.Session.GetInt32("flightId")});
        }

        /// <summary>
        /// Call the method to book a flight and redirect to the index page of the AvailableFlight controller
        /// </summary>
        /// <param name="booking"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult BookTicket(TicketBooking booking)
        {
            booking.FlightID = (int)HttpContext.Session.GetInt32("flightId");
            _vsFlyServices.BookTicket(booking);
            return RedirectToAction("Index", "AvailableFlights");
        }
    }
}
