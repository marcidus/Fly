﻿using Microsoft.CodeAnalysis.CSharp.Syntax;
using Newtonsoft.Json;
using System.Text;
using WebFlyClient.Models;

namespace WebFlyClient.Services
{
    public class VsFlyServices : IVsFlyServices
    {
        private readonly HttpClient _client;
        private readonly string _baseURI;

        public VsFlyServices(HttpClient client)
        {
            _client = client;
            _baseURI = "https://localhost:7198/api/Flight/"; // à changer
        }

        public async void BookTicket(TicketBooking booking)
        {
            var uri = _baseURI + "bookFlight/" + booking.PassengerId + "&" + booking.FlightID;
            var json = JsonConvert.SerializeObject(booking);

            HttpContent stringContent = new StringContent(json, Encoding.UTF8, "application/json");

            await _client.PutAsync(uri.ToString(), null);
        }

        public async Task<Price> GetAveragePrice(string destination)
        {
            var uri = _baseURI + "AverageTicketPrice/" + destination;

            var responseJSON = await _client.GetAsync(uri);
            responseJSON.EnsureSuccessStatusCode();

            var data = await responseJSON.Content.ReadAsStringAsync();

            data = data.Replace('.', ',');

            Price averagePrice = new Price() { Price = Convert.ToDouble(data) };

            return averagePrice;

        }

        public async Task<IEnumerable<Flight>> GetFlights()
        {
            var uri = _baseURI + "AvailableFlights";

            var responseJSON = await _client.GetAsync(uri);
            responseJSON.EnsureSuccessStatusCode();

            var data = await responseJSON.Content.ReadAsStringAsync();

            var flights = JsonConvert.DeserializeObject<IEnumerable<Flight>>(data);

            return flights;
        }

        public async Task<Price> GetPrice(int id)
        {
            var uri = _baseURI + "FlightPrice/" + id;

            var responseJSON = await _client.GetAsync(uri);
            responseJSON.EnsureSuccessStatusCode();

            var data = await responseJSON.Content.ReadAsStringAsync();

            Price price = new Price
            {
                Price = Convert.ToDouble(data)
            };
            
            return price;
        }

        public async Task<IEnumerable<Ticket>> GetTicket(string destination)
        {
            var uri = _baseURI + "BookedTickets/" + destination;

            var responseJSON = await _client.GetAsync(uri);
            responseJSON.EnsureSuccessStatusCode();

            var data = await responseJSON.Content.ReadAsStringAsync();

            var tickets = JsonConvert.DeserializeObject<IEnumerable<Ticket>> (data);

            return tickets;
        }

        public async Task<Price> GetTotalSalePrice(int id)
        {
            var uri = _baseURI + "FlightTotalSalePrice/" + id;

            var responseJson = await _client.GetAsync(uri);
            responseJson.EnsureSuccessStatusCode();

            var data = await responseJson.Content.ReadAsStringAsync();

            Price totalPrice = new Price { Price = Convert.ToDouble(data) };

            return totalPrice;
        }
    }
}
