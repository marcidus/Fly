﻿using WebFlyClient.Controllers;
using WebFlyClient.Models;

namespace WebFlyClient.Services
{
    public interface IVsFlyServices
    {
        public Task<IEnumerable<WebFlyClient.Models.Flight>> GetFlights();
        public Task<Price> GetPrice(int id);
        public Task<Price> GetTotalSalePrice(int id);
        public void BookTicket(TicketBooking booking);
        public Task<Price> GetAveragePrice(string destination);
        public Task<IEnumerable<WebFlyClient.Models.Ticket>> GetTicket(string destination);
       
    }
}
