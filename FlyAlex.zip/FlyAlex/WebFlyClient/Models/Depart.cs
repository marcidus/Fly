﻿namespace WebFlyClient.Models
{
    public class Depart
    {
        public int DepartID { get; set; }
        public string DepartName { get; set;}
        public DateTime DepartTime { get; set; }
    }
}
