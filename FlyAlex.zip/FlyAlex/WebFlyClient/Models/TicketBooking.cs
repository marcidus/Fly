﻿namespace WebFlyClient.Models
{
    public class TicketBooking
    {
        public int PassengerId { get; set; }
        public int FlightID { get; set; }
    }
}
