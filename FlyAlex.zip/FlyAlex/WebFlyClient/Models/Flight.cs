﻿namespace WebFlyClient.Models
{
    public class Flight
    {
        public int FlightId { get; set; }
        public DateTime Date { get; set; }
        public string Depart { get; set; }
        public string Destination { get; set; }
        public int FlightNo { get; set; }
        public int FreeSeat { get; set; }
    }
}
