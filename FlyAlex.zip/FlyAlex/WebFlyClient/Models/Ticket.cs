﻿namespace WebFlyClient.Models
{
    public class Ticket
    {
        public int TicketID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int FlightNo { get; set; }
        public double Price { get; set; }
    }
}
