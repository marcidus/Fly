﻿namespace WebFlyClient.Models
{
    public class Price
    {
        public double Price { get; set; }
    }
}
