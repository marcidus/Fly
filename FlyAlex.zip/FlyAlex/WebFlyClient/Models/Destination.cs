﻿namespace WebFlyClient.Models
{
    public class Destination
    {
        public int DestinationID { get; set; }
        public string DestinationName { get; set; }
        public DateTime DestinationTime { get; set; }
    }
}
