﻿using API.Models;
using FlyAlex.Models;

internal static class ConverterExtensionsHelpers
{

    public static IEnumerable<FinalTicket> ConvertToBookedTickets(this Flight flight)
    {
        List<FinalTicket> tickets = new List<FinalTicket>();
        foreach (Booking booking in flight.Bookings)
        {
            FinalTicket finalTicket = new FinalTicket();
            finalTicket.FirstName = booking.Passenger == null ? DELETED : booking.Passenger.Surname;
            finalTicket.LastName = booking.Passenger == null ? DELETED : booking.Passenger.FullName;
            finalTicket.FlightNbr = flight.FlightNo;
            finalTicket.Price = flight.Price;
            tickets.Add(finalTicket);
        }
    }
}